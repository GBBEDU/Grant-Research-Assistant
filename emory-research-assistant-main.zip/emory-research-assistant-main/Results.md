![image](https://github.com/ganachan/emory-research-assistant/assets/70560170/5b8f682c-f28a-4b60-bdbb-f60f8f63e141)
